package app.food.patient_app.model;

public class ForgotPasswordModel {

    /**
     * status : 0
     * messgae : Please Check You E-Mail
     */

    private String status;
    private String messgae;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessgae() {
        return messgae;
    }

    public void setMessgae(String messgae) {
        this.messgae = messgae;
    }
}
