package app.food.patient_app.data;


public class IgnoreItem {
    public String mPackageName;
    public long mCreated;
    public String mName;
}
