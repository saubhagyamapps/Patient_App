package app.food.patient_app.model;

public class GetSMSCountModel {

    /**
     * status : 0
     * count : 2
     */

    private String status;
    private int count;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
