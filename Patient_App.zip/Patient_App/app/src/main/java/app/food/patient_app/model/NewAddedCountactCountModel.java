package app.food.patient_app.model;

public class NewAddedCountactCountModel {

    /**
     * status : 0
     * count : 5
     */

    private String status;
    private String count;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
}
