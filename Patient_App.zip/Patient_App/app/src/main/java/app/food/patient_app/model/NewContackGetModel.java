package app.food.patient_app.model;

public class NewContackGetModel {

    /**
     * status : 0
     * result : Insert Successfully
     */

    private String status;
    private String result;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
